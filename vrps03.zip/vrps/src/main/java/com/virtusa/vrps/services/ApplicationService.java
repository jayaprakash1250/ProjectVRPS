package com.virtusa.vrps.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.virtusa.vrps.models.Application;
import com.virtusa.vrps.repositories.ApplicationRepo;

@Service
public class ApplicationService {

	@Autowired
	private ApplicationRepo applicationRepo;
	
	public Application saveApplication(Application application) {
		return applicationRepo.save(application);

	}

	public List<Application> getAllApplications() {
		return applicationRepo.findAll();

	}

	public Application getApplicationById(int applicationId) {
		return applicationRepo.findById(applicationId).orElse(null);
	}
	
}
