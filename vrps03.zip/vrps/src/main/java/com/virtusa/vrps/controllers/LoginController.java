package com.virtusa.vrps.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	
	
	  @GetMapping("/adminHome") public String adminHome() { return "adminHome"; }
	  
	  @GetMapping("/employeeHome") public String employeeHome() { return
	  "employeeHome"; }
	 
	
	@GetMapping("/loginError")
	  public String loginError(Model model) {
	    model.addAttribute("loginError", true);
	    return "login";
	  }
}
