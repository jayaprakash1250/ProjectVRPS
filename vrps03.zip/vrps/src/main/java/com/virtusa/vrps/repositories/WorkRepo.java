package com.virtusa.vrps.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.vrps.models.Work;

public interface WorkRepo extends JpaRepository<Work, Integer>{

}
