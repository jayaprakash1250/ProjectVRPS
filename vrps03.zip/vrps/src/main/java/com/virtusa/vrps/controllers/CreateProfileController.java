package com.virtusa.vrps.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.virtusa.vrps.models.Company;
import com.virtusa.vrps.models.Education;
import com.virtusa.vrps.models.Personal;
import com.virtusa.vrps.models.Work;
import com.virtusa.vrps.services.CompanyService;
import com.virtusa.vrps.services.EducationService;
import com.virtusa.vrps.services.PersonalService;
import com.virtusa.vrps.services.WorkService;

public class CreateProfileController {

	@Autowired
	private PersonalService personalService;

	@Autowired
	private WorkService workService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private EducationService educationService;

	@PostMapping("/savePersonal")
	public void savePersonal(@ModelAttribute Personal personal, Model model) {
		model.addAttribute("personal", personalService.savePersonal(personal));

	}

	@PostMapping("/saveWork")
	public void saveWork(@ModelAttribute Work work, Model model) {
		model.addAttribute("work", workService.saveWork(work));

	}

	@PostMapping("/saveCompany")
	public void saveCompany(@ModelAttribute Company	company, 
			Model model)
	{
		model.addAttribute("company", companyService.saveCompany(company));	
	}

	/*
	 * @PostMapping("/saveEducation") public String
	 * saveWork(@ModelAttribute("Education") , Model model) {
	 * model.addAttribute("work", workService.saveWork(work));
	 * 
	 * return "addproduct";
	 * 
	 * }
	 */
	
	
	
	
	
}
