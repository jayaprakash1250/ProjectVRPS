package com.virtusa.vrps.models;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Application")
public class Application {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int applicationId;
	@OneToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
	@JoinColumn
	private Employee employee;
	
	@OneToOne
	private Job job;
	
    public Job getJob() {
		return job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	@ManyToOne(cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
    @JoinColumn
    private Admin admin;
    @Column
	private int referenceId;
	private int adminStatus;
	private int trStatus;
	private int hrStatus;
	

	public int getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public int getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(int referenceId) {
		this.referenceId = referenceId;
	}

	public int getAdminStatus() {
		return adminStatus;
	}

	public void setAdminStatus(int adminStatus) {
		this.adminStatus = adminStatus;
	}

	public int getTrStatus() {
		return trStatus;
	}

	public void setTrStatus(int trStatus) {
		this.trStatus = trStatus;
	}

	public int getHrStatus() {
		return hrStatus;
	}

	public void setHrStatus(int hrStatus) {
		this.hrStatus = hrStatus;
	}
}
