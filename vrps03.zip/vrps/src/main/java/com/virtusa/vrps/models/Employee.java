package com.virtusa.vrps.models;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")
@PrimaryKeyJoinColumn
public class Employee extends Person {
	
	
	/*
	 * @OneToOne private Application application;
	 * 
	 * @OneToOne private Personal personal;
	 * 
	 * @OneToOne private Work work;
	 * 
	 * @OneToMany private List<Education> education;
	 * 
	 * @OneToOne private Job job;
	 */
	
	/*
	 * @OneToMany
	 * 
	 * @JoinColumn(name = "Rating") private List<RatingAndComments>
	 * ratingAndComments;
	 * 
	 * public List<RatingAndComments> getRatingAndComments() { return
	 * ratingAndComments; } public void setRatingAndComments(List<RatingAndComments>
	 * ratingAndComments) { this.ratingAndComments = ratingAndComments; }
	 * 
	 * public Personal getPersonal() { return personal; } public void
	 * setPersonal(Personal personal) { this.personal = personal; } public Work
	 * getWork() { return work; } public void setWork(Work work) { this.work = work;
	 * }
	 * 
	 * public Application getApplication() { return application; } public void
	 * setApplication(Application application) { this.application = application; }
	 * public List<Education> getEducation() { return education; } public void
	 * setEducation(List<Education> education) { this.education = education; }
	 * public Job getJob() { return job; } public void setJob(Job job) { this.job =
	 * job; }
	 * 
	 */
}
