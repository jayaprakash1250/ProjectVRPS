package com.virtusa.vrps.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.vrps.models.Application;

public interface ApplicationRepo extends JpaRepository<Application, Integer>{

}
