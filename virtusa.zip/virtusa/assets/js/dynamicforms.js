function addProject(divname)
{
   
 	var newdiv=document.createElement('div');
 	newdiv.innerHTML="<br><input type='text' name='tex'>";
 	document.getElementById("divname").appendChild("newdiv");




	/*var form=document.getElementById("applyjob");
	var title=document.createElement("input");
    title.type="text";
    title.name="titles[]";
    var technolgies=document.createElement("input");
    technolgies.type="text";
    technolgies.name="technolgies[]";
    var sdate=document.createElement("input");
    sdate.type="date";
    sdate.name="sdate[]";
    var edate=document.createElement("input");
    edate.type="date";
    edate.name="edate[]";
    var description=document.createElement("input");
    description.type="textarea";
    description.anem="description[]";

    var remove=document.createElement("input");
    remove.type="button";
    remove.value="remove";
    remove.onclick="dleteproject(this)";

    var para=document.createElement("p");
    para.appendChild(title);
    para.appendChild(technolgies);
    para.appendChild(sadte);
    para.appendChild(eadte);
    para.appendChild(textarea);
    form.insertBefore(title,element);
    form.insertBefore(technolgies,element);
    form.insertBefore(sadte,element);
    form.insertBefore(edate,element);
    form.insertBefore(remove,element)*/

}