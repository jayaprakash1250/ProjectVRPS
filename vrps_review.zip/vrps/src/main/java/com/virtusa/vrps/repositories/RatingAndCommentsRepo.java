package com.virtusa.vrps.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.virtusa.vrps.models.RatingAndComments;

public interface RatingAndCommentsRepo extends JpaRepository<RatingAndComments, Integer>{
	
	@Query("SELECT rac FROM RatingAndComments rac WHERE rac.employee.employeeId = :employeeid")
	List<RatingAndComments> getAllRatingsAndComments(@Param("employeeid") int employeeid);

}
