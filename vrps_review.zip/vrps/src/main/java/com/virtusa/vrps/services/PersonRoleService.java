package com.virtusa.vrps.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.vrps.models.PersonRole;
import com.virtusa.vrps.repositories.PersonRoleRepo;

@Service
public class PersonRoleService {
	
	@Autowired
	private PersonRoleRepo personRoleRepo;
	
	public List<PersonRole> getRoleById(int employeeID) {
		return personRoleRepo.getUserRolesByID(employeeID);
	}
	
	public PersonRole savePersonRole(PersonRole personRole) {
		
		return personRoleRepo.save(personRole);
		
	}

}
