package com.virtusa.vrps.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.vrps.models.Work;
import com.virtusa.vrps.repositories.WorkRepo;

@Service
public class WorkService {

	@Autowired
	private WorkRepo workRepo;
	
	public Work saveWork(Work work)
	{
		return workRepo.save(work);
	}
	
	public List<Work> findAllWorkDetails()
	{
		return workRepo.findAll();
	}
	
	public  Work  getWorkById(int employeeId) {
		return workRepo.getUserWorkByID(employeeId);	
	}
	
	public List<Work> customeFindAllWorkDetails(String Role)
	{
		List<Work> works=null;
		if(Role.contains("ADMIN")) {
			works = workRepo.customeWorkListAdmin(0);
		}
		else if(Role.contains("TR")) {
			works = workRepo.customeWorkListAdmin(1);
		}
		else if(Role.contains("HR")) {
			works = workRepo.customeWorkListTr(1);
		}
		return works;
	}
	
	public List<Work> customeFindSelectedWorkDetails(String Role)
	{

		List<Work> works=null;
		if(Role.contains("ADMIN")) {
			works = workRepo.customeWorkListAdmin(1);
		}
		else if(Role.contains("TR")) {
			works = workRepo.customeWorkListTr(1);
		}
		else if(Role.contains("HR")) {
			works = workRepo.customeWorkListHr(1);
		}
		return works;
	}
}

